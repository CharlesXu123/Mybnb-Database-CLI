create definer = root@localhost trigger being_rented_trigger
    before insert
    on being_rented
    for each row
BEGIN
    IF new.start_data >= new.end_data THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'rent date invalid, start date earlier than end date';
    END IF;
END;

