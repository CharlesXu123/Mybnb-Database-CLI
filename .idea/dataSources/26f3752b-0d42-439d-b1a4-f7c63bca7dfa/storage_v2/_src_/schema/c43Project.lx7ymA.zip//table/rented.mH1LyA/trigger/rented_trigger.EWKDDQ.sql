create definer = root@localhost trigger rented_trigger
    before insert
    on rented
    for each row
BEGIN
    IF new.start_date >= new.end_date THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'rent date invalid, start date earlier than end date';
    END IF;
END;

