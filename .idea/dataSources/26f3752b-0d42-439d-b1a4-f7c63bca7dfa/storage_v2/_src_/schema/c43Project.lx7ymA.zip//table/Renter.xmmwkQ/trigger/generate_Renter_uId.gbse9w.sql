create definer = root@localhost trigger generate_Renter_uId
    before insert
    on Renter
    for each row
BEGIN
    IF new.uId IS NULL THEN
        SET new.uId = uuid();
    END IF;
END;

