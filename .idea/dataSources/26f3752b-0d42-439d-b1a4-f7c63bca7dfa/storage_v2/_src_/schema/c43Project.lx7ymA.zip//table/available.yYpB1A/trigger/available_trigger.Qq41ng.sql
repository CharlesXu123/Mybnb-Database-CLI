create definer = root@localhost trigger available_trigger
    before insert
    on available
    for each row
BEGIN
    IF new.uid IS NULL THEN
        SET new.uid = uuid();
    end if;

end;

