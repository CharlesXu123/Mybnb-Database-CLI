create definer = root@localhost trigger renter_delete_trigger
    before delete
    on renter
    for each row
BEGIN
    UPDATE rented SET canceled = true WHERE rented.rId = OLD.uId AND rented.end_date > CURDATE();
end;

