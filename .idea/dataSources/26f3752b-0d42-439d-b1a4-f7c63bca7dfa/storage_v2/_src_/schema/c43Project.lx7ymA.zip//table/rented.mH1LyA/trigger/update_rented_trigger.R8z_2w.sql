create definer = root@localhost trigger update_rented_trigger
    before update
    on rented
    for each row
BEGIN
        IF NEW.end_date < CURDATE() THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'you can not cancel complete booking!';
        end if;
        UPDATE available SET available=true WHERE available.lId = NEW.lId AND available.query_date >= NEW.start_date AND available.query_date<= NEW.end_date;
    end;

