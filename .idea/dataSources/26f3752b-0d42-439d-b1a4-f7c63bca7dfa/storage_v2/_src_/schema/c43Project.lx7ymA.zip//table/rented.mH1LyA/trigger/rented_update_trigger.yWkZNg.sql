create definer = root@localhost trigger rented_update_trigger
    before update
    on rented
    for each row
BEGIN
    IF NEW.lId IS NUlL OR NEW.hId IS NULL OR NEW.rId IS NULL THEN
    SET NEW.canceled = true;
end if;

end;

