create definer = root@localhost trigger rented_cleanup_trigger
    after update
    on rented
    for each row
BEGIN
    IF OLD.lId IS NULL AND OLD.hId IS NULL AND OLD.rId IS NULL THEN
        DELETE FROM rented WHERE rented.rentedId = OLD.rentedId;
    end if;
end;

