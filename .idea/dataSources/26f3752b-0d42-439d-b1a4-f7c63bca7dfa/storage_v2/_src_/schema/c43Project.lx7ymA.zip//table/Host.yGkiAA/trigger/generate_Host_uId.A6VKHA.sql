create definer = root@localhost trigger generate_Host_uId
    before insert
    on Host
    for each row
BEGIN
    IF new.uId IS NULL THEN
        SET new.uId = uuid();
    END IF;
END;

