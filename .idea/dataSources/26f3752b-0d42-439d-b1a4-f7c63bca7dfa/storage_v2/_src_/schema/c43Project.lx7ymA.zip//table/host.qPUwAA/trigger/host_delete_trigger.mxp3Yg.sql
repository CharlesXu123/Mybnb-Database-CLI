create definer = root@localhost trigger host_delete_trigger
    before delete
    on host
    for each row
BEGIN
    DELETE FROM listing WHERE listing.lId IN (SELECT lId FROM owned WHERE owned.uId = OLD.uId);
    UPDATE rented SET canceled = false WHERE rented.hId = OLD.uId;
end;

