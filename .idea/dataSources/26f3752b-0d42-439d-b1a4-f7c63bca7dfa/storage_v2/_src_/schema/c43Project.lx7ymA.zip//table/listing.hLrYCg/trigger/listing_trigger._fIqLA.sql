create definer = root@localhost trigger listing_trigger
    before insert
    on listing
    for each row
BEGIN
    IF new.uid IS NULL THEN
        SET new.uid = uuid();
    end if;

end;

