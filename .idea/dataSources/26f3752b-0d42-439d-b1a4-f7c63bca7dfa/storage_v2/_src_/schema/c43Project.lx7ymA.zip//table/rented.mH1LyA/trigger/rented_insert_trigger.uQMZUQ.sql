create definer = root@localhost trigger rented_insert_trigger
    before insert
    on rented
    for each row
BEGIN
    IF NEW.rentedId IS NULL THEN
        SET NEW.rentedId = uuid();
    end if;
END;

