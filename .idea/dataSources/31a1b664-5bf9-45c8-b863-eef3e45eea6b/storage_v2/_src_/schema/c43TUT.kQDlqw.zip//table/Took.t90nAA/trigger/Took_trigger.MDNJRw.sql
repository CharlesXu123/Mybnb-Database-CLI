create definer = root@localhost trigger Took_trigger
    before insert
    on Took
    for each row
BEGIN
DECLARE msg varchar(255);
IF NEW.grade > 100 OR  NEW.grade < 0 THEN
SET msg = 'Constraints violated!';
SIGNAL sqlstate '45000' set message_text = msg;
END IF;
END;

